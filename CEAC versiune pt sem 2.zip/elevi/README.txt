 * FORMULAR CEAC VERSION 1.0 Stable
 * Copyright (c) 2014 BURCOVSCHI DAVID <burcovschidavid@gmail.com>
 * 
 * ALL RIGHTS RESERVED. NO WARRANTY, EXPLICIT OR IMPLICIT, PROVIDED.
 * BURCOVSCHI DAVID IS AUTHOR OF THIS SOFTWARE.
 * IT CANNOT BE DISTRIBUTED OR USED IN ANY MANNER, SHAPE OR FORM WITHOUT MY ACCORD. 
 * NUMBER OF CODE LINES WROTE IS 572 LINES OF CODE
 * IF YOU DETECT SOME BUGGS OR ERRORS PLEASE CONTACT-ME AT burcovschidavid@yahoo.com or burcovschidavid@gmail.com
 * I'M NOT RESPOSABLE FOR FURTHER DEMAGE CAUSED BY USING THIS SOFTWARE



Atentie! Pentru instalarea acestui formular este necesar:
     - un server pentru baze de date MYSLQ 5.6.17
	 - un server Apache versiune >2.4
	 - interpretor PHP versiune> 5.5
	 
INSTALAREA:
   -Se introduce in bara de adresa: localhost/elevi/install.php sau calea ta unde se afla folderul /elevi , obligatoriu 
    instalarea se face de pe localhost nu din alta adresa, deci implicit direct de pe server. Daca totul este cu succes, 
	veti fi redirectionati la pagina principala a platfomei adica la formular.
	
	


