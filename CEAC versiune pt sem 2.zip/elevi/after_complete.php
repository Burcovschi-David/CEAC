<!doctype html>

<head></head>
<title>LIIS::Elevi formular::Felicitari!</title>
<html>
 <body bgcolor="#FFFFDA">
  <hr>
   <center>
    <img src="poze/sigla.png">
   </center>
   <hr>
   <br>
   <br>
   <center>
   <table border="0" bgcolor="#FFFFF2" align="center">
    <tr>
	 <td>
	 <center>
	  <h1>Felicitari, ai completat cu succes formularul CEAC!</h1>
	  <h3><a href="http://www.google.com">Click aici pentru a intra pe Google !</a></h3>
	  </center>
	 </td>
	</tr>
   </table>
	<br><br>
	<h3>Powered by David Burcovschi</h3>
	</center>
  </body>
 </html>