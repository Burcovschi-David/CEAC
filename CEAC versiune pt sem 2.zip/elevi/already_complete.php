<!doctype html>

<head></head>
<title>LIIS::Elevi formular::Ups!</title>
<html>
 <body bgcolor="#FFFFDA">
  <hr>
   <center>
    <img src="poze/sigla.png">
   </center>
   <hr>
   <br>
   <br>
   <center>
   <table border="0" bgcolor="#FFFFF2" align="center">
    <tr>
	 <td>
	 <center>
	  <h1>Acest elev a completat deja formularul CEAC!</h1>
	  <h3><a href="index.php">Click aici pentru a incerca din nou !</a></h3>
	  </center>
	 </td>
	</tr>
   </table>
	<br><br>
	<h3>Powered by David Burcovschi</h3>
	</center>
  </body>
 </html>