<!doctype html>
<head><center><style type="text/css">
body{
background-image: url(poze/background.jpg);
background-repeat: no-repeat;
background-attachment: fixed;
background-position: center;
-webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;

}
</style></center></head>
<title>LIIS::Index::</title>
<html>

<body>

 <center>
  <hr>
   <h1>
    Alegeti ce formular vreti sa completati
   </h1>
   <hr>
  </center>
   <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
   <table bgcolor="#FFFFF2" border="0" align="center" >
    <tr>
     <td>
      <form action="prelucrare.php" method="POST">
      <select name="clasa_de_vazut">
  <option value="5A">Clasa 5 A</option>
  <option value="5B">Clasa 5 B</option>
  <option value="5C">Clasa 5 C</option>
  <option value="6A">Clasa 6 A</option>
  <option value="6B">Clasa 6 B</option>
  <option value="6C">Clasa 6 C</option>
  <option value="7A">Clasa 7 A</option>
  <option value="7B">Clasa 7 B</option>
  <option value="7C">Clasa 7 C</option>
  <option value="8A">Clasa 8 A</option>
  <option value="8B">Clasa 8 B</option>
  <option value="8C">Clasa 8 C</option>
  <option value="9A">Clasa 9 A</option>
  <option value="9B">Clasa 9 B</option>
  <option value="9C">Clasa 9 C</option>
  <option value="9D">Clasa 9 D</option>
  <option value="9E">Clasa 9 E</option>
  <option value="9F">Clasa 9 F</option>
  <option value="10A">Clasa 10 A</option>
  <option value="10B">Clasa 10 B</option>
  <option value="10C">Clasa 10 C</option>
  <option value="10D">Clasa 10 D</option>
  <option value="10E">Clasa 10 E</option>
  <option value="10F">Clasa 10 F</option>
  <option value="11A">Clasa 11 A</option>
  <option value="11B">Clasa 11 B</option>
  <option value="11C">Clasa 11 C</option>
  <option value="11D">Clasa 11 D</option>
  <option value="11E">Clasa 11 E</option>
  <option value="12A">Clasa 12 A</option>
  <option value="12B">Clasa 12 B</option>
  <option value="12C">Clasa 12 C</option>
  <option value="12D">Clasa 12 D</option>
  <option value="12E">Clasa 12 E</option>
  <option value="12F">Clasa 12 F</option>
  </select><br><br>
       <input type="submit" name="Alege" value="Alege!"><br>
      </form>
     </td>
    </tr>
   </table>
  </body>
 </html>

